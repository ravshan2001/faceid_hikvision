import{d as r,r as t}from"./index-DJQ9dgx6.js";const a=r("headerShowStore",()=>{const e=t(!1);return{show:e,setShow:o=>{e.value=o}}});export{a as h};
