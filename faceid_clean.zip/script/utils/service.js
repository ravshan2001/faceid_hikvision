import { UserModel } from "../models/user.js";
import { EventModel } from "../models/event.js";
import { getAllDoors, getAllOpenDoors, getUsersNotSynced } from "./request.js";
import { hikEventsSync, newHikUser, removeHikUser } from "./hikvision.js";
import { getSocket } from "../socket.io.js";

export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const addUser = async (userData) => {
  try {
    await newHikUser(userData);
  } catch (error) {
    console.error("Service error:", error);
  }
};

export const syncUser = async () => {
  try {
    let { data, status } = await getUsersNotSynced();
    if (status === 200) {
      for (const value of data) {
        await UserModel.findOneAndUpdate(
          { employeeNo: value.employeeNo },
          { employeeNo: value.employeeNo },
          { upsert: true }
        );
      }
    }
  } catch (error) {
    console.error("Service error:", error);
  }
};

export const removeUser = async (door, employeeNo) => {
  try {
    await removeHikUser(door, employeeNo);
  } catch (error) {
    console.error("Service error:", error);
  }
};

// ✅ TO'G'RILANGAN: Events hikvision.js da DB ga yoziladi
// Bu funksiya faqat chaqiradi, socket emit QILMAYDI
export const getEvents = async (start, end, type, offset, syncDoors) => {
  try {
    let response = null;
    if (process.env.MODE === "APP") {
      response = await getAllDoors();
    } else if (process.env.MODE === "SCRIPT") {
      response = await getAllOpenDoors();
    }

    if (!response || response.status !== 200) {
      console.log("No doors available or error fetching doors");
      return {};
    }

    let startDay = new Date(start);
    startDay.setHours(0, 0, 0, 0);
    const startDayUTC = startDay.toISOString().replace(/\.\d+Z$/, "+05:00");

    let endDay = new Date(end);
    endDay.setHours(23, 59, 59, 999);
    const endDayUTC = endDay.toISOString().replace(/\.\d+Z$/, "+05:00");

    if (type === "sync") {
      // Manual sync: frontend yuborgan vaqt oralig'ida
      let io = await getSocket();
      let totalSaved = 0;

      for (const door of syncDoors) {
        const doorEvents = await hikEventsSync([door], offset, {
          start: startDayUTC,
          end: endDayUTC,
        });

        const count = Object.values(doorEvents).flat().length;
        totalSaved += count;
        await new Promise((res) => setTimeout(res, 1500));
      }

      if (totalSaved === 0) {
        console.log("Sync tugadi, yangi event yo'q.");
        io.emit("sync-end", "sync-end");
        return {};
      }

      // Keyingi batch
      const nextOffset = offset + 20;
      setTimeout(async () => {
        await eventSync(start, end, nextOffset, syncDoors);
      }, 2000);

      // Frontend ga xabar
      io.emit("new-events", { count: totalSaved });
      return {};
    } else {
      // ✅ NORMAL (cron) mode: barcha doors, faqat bugun
      let doors = response.data;
      let totalSaved = 0;

      for (const door of doors) {
        const doorEvents = await hikEventsSync([door], 0, {
          start: startDayUTC,
          end: endDayUTC,
        });
        const count = Object.values(doorEvents).flat().length;
        totalSaved += count;
        console.log(`Door ${door.ip}: ${count} events saved`);
        await new Promise((res) => setTimeout(res, 1000));
      }

      if (totalSaved > 0) {
        // Frontend ga xabar ber
        try {
          let io = await getSocket();
          io.emit("new-events", { count: totalSaved });
        } catch (e) {
          // socket bo'lmasa ham davom et
        }
      }

      return {};
    }
  } catch (error) {
    console.error("Service getEvents error:", error);
  }
};

export const eventSync = async (start, end, offset, syncDoors) => {
  try {
    let io = await getSocket();
    await getEvents(start, end, "sync", offset, syncDoors);
  } catch (error) {
    console.error("Service eventSync error:", error);
  }
};
