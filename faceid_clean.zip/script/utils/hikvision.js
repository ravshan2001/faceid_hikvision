import fetch from "node-fetch";
globalThis.fetch = fetch;

import DigestFetch from "digest-fetch";
import FormData from "form-data";
import mongoose from "mongoose";

import { EventModel } from "../models/event.js";
import { UserModel as SyncedUserModel } from "../models/user.js"; // bu endi faqat synced_users uchun ishlaydi
import { syncedDoor, uploadFace } from "./request.js";
import { sleep } from "./service.js";

/**
 * SETTINGS (env)
 *  - SERVER_URI or PUBLIC_BASE_URL: public URL where face images are reachable (nginx /files/...)
 *  - HIK_MAJOR / HIK_MINOR: event filter (default 5/75)
 */
const PUBLIC_BASE = (process.env.PUBLIC_BASE_URL || process.env.SERVER_URI || "").replace(/\/+$/, "");
const HIK_MAJOR = Number(process.env.HIK_MAJOR || 5);
const HIK_MINOR = Number(process.env.HIK_MINOR || 75);

// --- helpers ---
const devBase = (door) => `http://${door.ip}:${door.port}`;

const safeJson = (txt) => {
  try { return JSON.parse(txt); } catch { return null; }
};

const readText = async (res) => {
  try { return await res.text(); } catch { return ""; }
};

const buildFaceUrl = (userData) => {
  if (!PUBLIC_BASE) throw new Error("SERVER_URI (or PUBLIC_BASE_URL) is not set");
  const path = String(userData.faceUrl || "").replace(/^\/+/, "");
  if (!path) throw new Error("userData.faceUrl is empty");
  return `${PUBLIC_BASE}/${path}`;
};

const ensureEmployeeNo = (employeeNo) => {
  const v = String(employeeNo ?? "").trim();
  if (!v) return null;
  return v;
};

// API users collection’ni xavfsiz o‘qish uchun model (index yaratmaydi!)
const ApiUserSchema = new mongoose.Schema(
  { employeeNo: mongoose.Schema.Types.Mixed },
  { strict: false, autoIndex: false, collection: "users" }
);
const ApiUserModel = mongoose.models.api_user || mongoose.model("api_user", ApiUserSchema);

// --- 1) create/update user on device (AccessControl) ---
const formatDate = (date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  const hh = String(date.getHours()).padStart(2, "0");
  const mm = String(date.getMinutes()).padStart(2, "0");
  const ss = String(date.getSeconds()).padStart(2, "0");
  return `${y}-${m}-${d}T${hh}:${mm}:${ss}`;
};

const ensureUserExists = async (client, userData) => {
  const emp = ensureEmployeeNo(userData.employeeNo);
  if (!emp) throw new Error("employeeNo is empty");

  let beginTime = new Date();
  let endTime = new Date();
  endTime.setFullYear(endTime.getFullYear() + 10);

  const payload = {
    UserInfo: {
      employeeNo: emp,
      name: String(userData.fullName || emp),
      userType: "normal",
      Valid: { enable: true, beginTime: formatDate(beginTime), endTime: formatDate(endTime), timeType: "local" },
      doorRight: "1",
      RightPlan: [{ doorNo: 1, planTemplateNo: "1" }],
      gender: userData.gender,
      localUIRight: false,
      maxOpenDoorTime: 0,
      userVerifyMode: "",
      floorNumbers: [],
      callNumbers: [],
    },
  };

  const url = `${devBase(userData.door)}/ISAPI/AccessControl/UserInfo/Record?format=json`;
  const res = await client.fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (res.ok) return { ok: true, existed: false };

  const txt = await readText(res);
  const j = safeJson(txt);

  if (j?.subStatusCode === "employeeNoAlreadyExist") return { ok: true, existed: true };

  const err = new Error(`Failed to create user: ${txt}`);
  err.hik = j || null;
  throw err;
};

// --- 2) upload face (WORKING multipart) ---
const uploadFaceMultipart = async (client, userData) => {
  const faceURL = buildFaceUrl(userData);

  const imgRes = await fetch(faceURL);
  if (!imgRes.ok) throw new Error(`Cannot download face image: HTTP ${imgRes.status} (${faceURL})`);
  const imageNodeBuffer = Buffer.from(await imgRes.arrayBuffer());

  const emp = ensureEmployeeNo(userData.employeeNo);
  if (!emp) throw new Error("employeeNo is empty");

  const formData = new FormData();

  // ✅ CURL’da ishlagan format: wrapper YO‘Q
  const faceDataForMultipart = {
    faceLibType: "blackFD",
    FDID: "1",
    FPID: emp,
    name: String(userData.fullName || emp),
  };

  formData.append("FaceDataRecord", JSON.stringify(faceDataForMultipart), {
    contentType: "application/json",
  });

  // ✅ field nomi: img
  formData.append("img", imageNodeBuffer, {
    filename: "face.jpg",
    contentType: "image/jpeg",
  });

  // ✅ MUHIM: Content-Length
  const headers = formData.getHeaders();
  const contentLength = await new Promise((resolve, reject) => {
    formData.getLength((err, length) => (err ? reject(err) : resolve(length)));
  });
  headers["Content-Length"] = String(contentLength);

  const url = `${devBase(userData.door)}/ISAPI/Intelligent/FDLib/FaceDataRecord?format=json`;
  const res = await client.fetch(url, { method: "POST", body: formData, headers });

  if (res.ok) return { ok: true };

  const txt = await readText(res);
  const j = safeJson(txt);
  const err = new Error(txt);
  err.hik = j || null;
  throw err;
};

// --- EXPORT: create user + face on device ---
export const newHikUser = async (userData) => {
  const client = new DigestFetch(userData.door.login, userData.door.password);
  const emp = ensureEmployeeNo(userData.employeeNo);

  try {
    if (!emp) throw new Error("employeeNo is empty");

    // 1) ensure user exists
    await ensureUserExists(client, userData);
    await sleep(250);

    // 2) upload face (multipart only)
    console.log(`[${emp}] Upload face (multipart: FaceDataRecord + img)...`);
    await uploadFaceMultipart(client, userData);

    // ✅ local tracking (separate collection)
    await SyncedUserModel.findOneAndUpdate({ employeeNo: emp }, { employeeNo: emp }, { upsert: true });

    await syncedDoor(userData._id, userData.door._id, "success");
    console.log(`[${emp}] ✅ User + face OK`);
  } catch (error) {
    await syncedDoor(userData._id, userData.door._id, "error").catch(() => {});
    console.error(`[${emp || "?"}] Hikvision CATCH error:`, error?.message || error);
  }
};



// --- IMPORTANT: DO NOT delete from DB here ---
export const removeHikUser = async (door, employeeNo, isError) => {

  if (!employeeNo || String(employeeNo).trim() === "") {
	  console.warn("removeHikUser: employeeNo empty, skipped");
	  return;
	}
  const emp=ensureEmployeeNo(employeeNo);

  if (!emp) {
    console.warn("removeHikUser skipped: employeeNo empty");
    return;
  }

  try {
    const client = new DigestFetch(door.login, door.password);
    const data = { UserInfoDelCond: { EmployeeNoList: [{ employeeNo: emp }] } };

    const response = await client.fetch(
      `http://${door.ip}:${door.port}/ISAPI/AccessControl/Userinfo/Delete?format=json`,
      { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }
    );

    if (!response.ok) {
      const txt = await readText(response);
      throw new Error(`Failed to remove user: ${txt}`);
    }

    if (!isError) await syncedDoor(emp, door._id, "removed").catch(() => {});
  } catch (e) {
    console.error("removeHikUser error:", e?.message || e);
  }
};

// --- EVENTS sync (save to DB with correct schema for calendar) ---
const mapAction = (d) => {
  // Hikvision’da ko‘p qurilmalarda: type: 0/1 (enter/exit)
  // Agar sendagi terminalda boshqacha bo‘lsa, shu joyni moslaysan.
  if (d?.type === 0) return "enter";
  if (d?.type === 1) return "exit";
  return "enter";
};

const getHikEvents = async (door, requestData) => {
  const client = new DigestFetch(door.login, door.password);

  const response = await client.fetch(
    `http://${door.ip}:${door.port}/ISAPI/AccessControl/AcsEvent?format=json`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(requestData) }
  );

  const responseBody = await response.json();
  const list = responseBody?.AcsEvent?.InfoList || [];

  // clean + sort + dedupe
  const filtered = list
    .filter((d) => d.currentVerifyMode !== "invalid" && d.employeeNoString)
    .sort((a, b) => new Date(a.time) - new Date(b.time))
    .filter((d, idx, arr) => {
      const next = arr[idx + 1];
      return !next || (new Date(next.time) - new Date(d.time) > 60000) || (d.employeeNoString !== next.employeeNoString);
    });

  const resData = await Promise.all(
    filtered.map(async (d) => {
      // API user’ni topamiz (users collection)
      const apiUser = await ApiUserModel.findOne({ employeeNo: d.employeeNoString }, "_id").lean();
      if (!apiUser?._id) return null;

      // event already exists?
      const exists = await EventModel.findOne(
        {
          door: door._id,
          employeeNoString: d.employeeNoString,
          time: { $gte: new Date(new Date(d.time).getTime() - 60000), $lte: new Date(new Date(d.time).getTime() + 60000) },
        },
        "_id"
      ).lean();

      if (exists?._id) return null;

      // pictureURL bo‘lsa: device’dan digest bilan olib, serverga upload
      let finalPicture = null;
      if (d.pictureURL) {
        const parseUrl = new URL(d.pictureURL);
        const path = encodeURI(parseUrl.pathname + parseUrl.search);

        const fileResponse = await client.fetch(`http://${door.ip}:${door.port}${path}`, { method: "GET" });
        if (fileResponse.ok) {
          const fileBuffer = Buffer.from(await fileResponse.arrayBuffer());
          const uploadRes = await uploadFace(fileBuffer);
          finalPicture = uploadRes?.data || null;
        }
      }

      const type = finalPicture ? "face" : "card";
      const action = mapAction(d);

      await EventModel.create({
        type,
        action,
        time: new Date(d.time),
        user: apiUser._id,
        door: door._id,
        employeeNoString: d.employeeNoString,
        serialNo: d.serialNo,
        pictureURL: finalPicture,
      });

      return {
        type,
        action,
        time: d.time,
        employeeNoString: d.employeeNoString,
        serialNo: d.serialNo,
        pictureURL: finalPicture,
      };
    })
  );

  const clean = resData.filter(Boolean);
  return { [door._id]: clean };
};

export const hikEventsSync = async (doors, offset, { start, end }) => {
  const requestData = {
    AcsEventCond: {
      searchID: "1",
      searchResultPosition: offset,
      maxResults: 20,
      major: HIK_MAJOR,
      minor: HIK_MINOR,
      startTime: start,
      endTime: end,
      timeReverseOrder: true,
    },
  };

  const eventRes = await Promise.all(doors.map((door) => getHikEvents(door, requestData)));

  return eventRes
    .filter(Boolean)
    .reduce((acc, curr) => {
      const [doorId, events] = Object.entries(curr)[0];
      acc[doorId] = events;
      return acc;
    }, {});
};
