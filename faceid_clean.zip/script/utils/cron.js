import { schedule } from "node-cron"
import { getEvents } from "./service.js";
import { getSocket } from "../socket.io.js";

export const appCronSchedule = async () => {
  try {
    let io = await getSocket();
    
    schedule("*/30 * * * * *", async () => {
      console.log("Cron: fetching events...");
      let today = new Date();  // ← har safar yangi sana!
      await getEvents(today, today, "normal", 0);
      // ← socket emit QILMAYMIZ, hikvision.js DB ga yozadi
    });
  } catch (error) {
    console.error(error);
  }
};
