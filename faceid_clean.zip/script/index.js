import dotenv from "dotenv";
dotenv.config();

import { socketCon } from "./socket.io.js";
import { appCronSchedule } from "./utils/cron.js";
import { connect } from "mongoose";


(async () => {
  await connect(process.env.MONGO_URI);
  console.log('MongoDB connected!');

  await socketCon();
  await appCronSchedule();
  console.log(`Server is running!`);
})();
