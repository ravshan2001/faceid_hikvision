import { io } from "socket.io-client";
import { sleep, addUser, removeUser, syncUser, eventSync } from "./utils/service.js";

let socket = null;

export const socketCon = async () => {
  socket = io(process.env.SERVER_URI, {
    reconnectionDelayMax: 1000,
    extraHeaders: {
      Authorization: process.env.MODE === "SCRIPT" ? "Bearer SCRIPT" : process.env.TOKEN,
    }
  });

  socket.on("connect", () => {
    console.log("connected");
    // syncUser();
  });

  socket.on("connect_error", (err) => {
    console.error("Connection error:", err.message);
  });

  socket.on("error", (error) => {
    console.log(error);
  });

  socket.on("disconnect", (reason) => {
    console.warn("Disconnected:", reason);
  });

  // start hik logic
  socket.on("new-user", async (data) => {
    await sleep(1500);
    await addUser(data)
  });

  socket.on("start-user-sync", async () => {
    await syncUser();
  });

  socket.on("user-remove", async ({ door, employeeNo }) => {
    await removeUser(door, employeeNo);
  });


  socket.on("event-sync", async ({ start, end, door }) => {
    await eventSync(start, end, 0, door);
  })
};

export const getSocket = () => {
  return new Promise((resolve, reject) => {
    if (socket) {
      resolve(socket);
    } else {
      console.error("Socket.io not initialized");
      reject("Socket.io not initialized");
    }
  });
};